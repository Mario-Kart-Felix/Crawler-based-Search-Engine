import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;
import org.jsoup.select.NodeVisitor;
import java.util.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;


public class IndexerModel{
    Map<Integer,String> map=new HashMap<Integer,String>();
    public IndexerModel(List<org.jsoup.nodes.Document> documents){

    for(int i =0; i<documents.size(); i++){

    }

}


}
