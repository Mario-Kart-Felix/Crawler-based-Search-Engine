import java.util.*;
public class Term {
   public Set<Page> pages = new HashSet<Page>();
        public Term(){
            pages = new HashSet<Page>();

        }
}
